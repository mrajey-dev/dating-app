<template>
  <div class="signup-container">
    <!-- Progress -->
    <div class="progress">
      <span>{{ currentStep + 1 }} / {{ stepTitles.length }}</span>
      <div class="bar">
        <div
          class="fill"
          :style="{ width: ((currentStep + 1) / stepTitles.length) * 100 + '%' }"
        ></div>
      </div>
    </div>

    <div class="card">
      <h2>{{ stepTitles[currentStep] }}</h2>

      <!-- STEP 1 : CONTACT DETAILS -->
      <div v-if="currentStep === 0">
        <label>Mobile Number</label>
        <div class="phone">
          <select v-model="form.countryCode">
            <option value="+91">🇮🇳 +91</option>
            <option value="+1">🇺🇸 +1</option>
            <option value="+44">🇬🇧 +44</option>
          </select>
          <input type="tel" v-model="form.mobile" placeholder="9876543210" />
        </div>

        <label>Email</label>
        <input type="email" v-model="form.email" placeholder="you@example.com" />

        <div class="name-row">
          <div>
            <label>First Name</label>
            <input v-model="form.firstName" placeholder="Ajay" />
          </div>
          <div>
            <label>Last Name</label>
            <input v-model="form.lastName" placeholder="Sharma" />
          </div>
        </div>
      </div>

      <!-- STEP 2 : LOCATION -->
      <div v-if="currentStep === 1" class="center">
        <p class="hint">
          {{ locationStatus || 'We use your location to show nearby matches' }}
        </p>
        <button class="primary full" @click="requestLocation">
          {{ locationGranted ? 'Location Enabled ✅' : 'Allow Location' }}
        </button>
      </div>

      <!-- STEP 3 : PROFILE PHOTO -->
      <div v-if="currentStep === 2" class="center">
        <div class="avatar">
          <img v-if="selfiePreview" :src="selfiePreview" />
          <span v-else>+</span>
        </div>

        <input
          type="file"
          accept="image/*"
          capture="user"
          hidden
          ref="cameraInput"
          @change="handleImage"
        />
        <input
          type="file"
          accept="image/*"
          hidden
          ref="galleryInput"
          @change="handleImage"
        />

        <button class="outline full" @click="$refs.cameraInput.click()">Take Selfie</button>
        <button class="outline full" @click="$refs.galleryInput.click()">Upload Photo</button>
      </div>

      <!-- STEP 4 : GENDER -->
      <div v-if="currentStep === 3" class="grid">
        <button class="chip" :class="{ active: form.gender==='Male' }" @click="form.gender='Male'">Male</button>
        <button class="chip" :class="{ active: form.gender==='Female' }" @click="form.gender='Female'">Female</button>
        <button class="chip" :class="{ active: form.gender==='Other' }" @click="form.gender='Other'">Other</button>
      </div>

      <!-- STEP 4.1 : DATE OF BIRTH -->
      <div v-if="currentStep === 4">
        <label>Date of Birth</label>
        <input type="date" v-model="form.dob" />
      </div>

      <!-- STEP 4.2 : GENDER PREFERENCE -->
      <div v-if="currentStep === 5" class="grid">
        <p>I'm interested in:</p>
        <button
          class="chip"
          :class="{ active: form.genderPreference.includes('Male') }"
          @click="togglePreference('Male')"
        >Male</button>
        <button
          class="chip"
          :class="{ active: form.genderPreference.includes('Female') }"
          @click="togglePreference('Female')"
        >Female</button>
        <button
          class="chip"
          :class="{ active: form.genderPreference.includes('Other') }"
          @click="togglePreference('Other')"
        >Other</button>
      </div>

      <!-- STEP 5 : STATUS -->
      <div v-if="currentStep === 6">
        <label>Status</label>
        <select v-model="form.status">
          <option disabled value="">Select status</option>
          <option>Single</option>
          <option>Married</option>
          <option>Divorced</option>
          <option>Separated</option>
          <option>Widowed</option>
        </select>
      </div>

      <!-- STEP 6 : SUBTITLE -->
      <div v-if="currentStep === 7">
        <label>Subtitle</label>
        <input v-model="form.subtitle" placeholder="Coffee • Travel • Music" />
      </div>

      <!-- STEP 7 : VERIFICATION BADGE -->
      <div v-if="currentStep === 8" class="grid">
        <button class="chip" :class="{ active: form.verified===1 }" @click="form.verified=1">
          Yes ✅ (Get Badge)
        </button>
        <button class="chip" :class="{ active: form.verified===0 }" @click="form.verified=0">
          No ❌
        </button>
      </div>

      <!-- STEP 8 : RATE -->
      <div v-if="currentStep === 9">
        <label>Rate (₹)</label>
        <input type="number" v-model="form.rate" placeholder="500" />
      </div>

      <!-- STEP 9 : HABITS -->
      <div v-if="currentStep === 10">
        <label>Habits</label>
        <input v-model="form.habits" placeholder="Gym, Yoga, Travel" />
      </div>

      <!-- STEP 10 : ABOUT -->
      <div v-if="currentStep === 11">
        <label>About Me</label>
        <textarea v-model="form.about"></textarea>
      </div>

      <!-- STEP 11 : ADD PHOTOS -->
      <div v-if="currentStep === 12" class="photos">
        <div v-for="(img,i) in photos" :key="i" class="photo">
          <img :src="img" />
        </div>
        <div class="photo add" @click="$refs.multiUpload.click()">+</div>
        <input
          type="file"
          multiple
          accept="image/*"
          hidden
          ref="multiUpload"
          @change="handleMultiplePhotos"
        />
      </div>

      <!-- STEP 12 : ADDRESS -->
      <div v-if="currentStep === 13">
        <label>City</label><input v-model="form.city" />
        <label>Address</label><input v-model="form.address" />
        <label>Pincode</label><input v-model="form.pincode" />
        <label>State</label><input v-model="form.state" />
        <label>Country</label><input disabled value="India" />
      </div>

      <!-- NAV -->
      <div class="nav">
        <button v-if="currentStep>0" class="ghost" @click="currentStep--">↩ Back</button>
        <button class="primary" @click="nextStep">
          {{ currentStep===stepTitles.length-1 ? 'Create Account' : 'Continue' }}
        </button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      currentStep: 0,
      stepTitles: [
        'Contact Details',
        'Location Access',
        'Profile Photo',
        'Gender',
        'Date of Birth',
        'Gender Preference',
        'Status',
        'Subtitle',
        'Verification Badge',
        'Rate',
        'Habits',
        'About Me',
        'Add Photos',
        'Address'
      ],
      locationGranted: false,
      locationStatus: '',
      selfiePreview: null,
      photos: [],
      form: {
        email: '',
        countryCode: '+91',
        mobile: '',
        firstName: '',
        lastName: '',
        gender: '',
        dob: '',
        genderPreference: [],
        status: '',
        subtitle: '',
        verified: 0,
        rate: '',
        habits: '',
        about: '',
        city: '',
        address: '',
        pincode: '',
        state: '',
        country: 'India',
        latitude: '',
        longitude: '',
        profilePhoto: null,
        gallery: []
      }
    }
  },
  methods: {
    nextStep() {
      if (this.currentStep < this.stepTitles.length - 1) {
        this.currentStep++;
      } else {
        // Submit form
        const formData = new FormData();
        for (let key in this.form) {
          if (key === 'gallery') {
            this.form.gallery.forEach(file => {
              formData.append('gallery[]', file);
            });
          } else if (key === 'profilePhoto') {
            if (this.form.profilePhoto) formData.append('profile_photo', this.form.profilePhoto);
          } else if (key === 'genderPreference') {
            this.form.genderPreference.forEach(pref => formData.append('gender_preference[]', pref));
          } else {
            formData.append(key, this.form[key]);
          }
        }
        formData.append('password', '123456'); // example default password
        fetch('http://localhost:8000/api/register', {
          method: 'POST',
          body: formData
        })
          .then(res => res.json())
          .then(data => {
            console.log('User saved:', data);
            alert('Account created successfully!');
          })
          .catch(err => console.error(err));
      }
    },
    requestLocation() {
      navigator.geolocation.getCurrentPosition(
        pos => {
          this.locationGranted = true
          this.locationStatus = 'Location access granted 🎯'
          this.form.latitude = pos.coords.latitude
          this.form.longitude = pos.coords.longitude
        },
        () => (this.locationStatus = 'Location permission denied')
      )
    },
    handleImage(e) {
      const file = e.target.files[0]
      if (!file) return
      this.form.profilePhoto = file
      this.selfiePreview = URL.createObjectURL(file)
    },
    handleMultiplePhotos(e) {
      const files = Array.from(e.target.files)
      files.forEach(f => this.photos.push(URL.createObjectURL(f)))
      this.form.gallery = files
    },
    togglePreference(gender) {
      const index = this.form.genderPreference.indexOf(gender)
      if (index > -1) {
        this.form.genderPreference.splice(index, 1)
      } else {
        this.form.genderPreference.push(gender)
      }
    }
  }
}
</script>


<style scoped>
.signup-container{min-height:100vh;max-width:420px;margin:auto;padding:64px 0 96px}
.progress{position:fixed;top:0;left:50%;transform:translateX(-50%);width:100%;max-width:420px;padding:14px;background:#fff;z-index:9}
.bar{height:3px;background:#e5e7eb;border-radius:99px;margin-top:6px}
.fill{height:100%;background:linear-gradient(90deg,#fd5068,#ff7854);transition:.3s}
.card{padding:18px}
h2{font-size:19px;font-weight:800;margin-bottom:20px}
label{margin-top:16px;display:block;font-size:13px;font-weight:600;color:#64748b}
input,select,textarea{width:100%;padding:16px;margin-top:6px;border-radius:16px;border:1px solid #e5e7eb}
textarea{min-height:120px}
.phone{display:flex;gap:10px}
.phone select{width:90px}
.name-row{display:flex;gap:12px}
.center{text-align:center}
.avatar{width:140px;height:140px;border-radius:50%;margin:20px auto;border:2px dashed #e5e7eb;display:flex;align-items:center;justify-content:center}
.avatar img{width:100%;height:100%;border-radius:50%;object-fit:cover}
.grid{display:grid;grid-template-columns:repeat(2,1fr);gap:14px}
.chip{padding:18px;border-radius:18px;border:1px solid #e5e7eb;font-weight:600}
.chip.active{background:linear-gradient(135deg,#fd5068,#ff7854);color:#fff;border:none}
.photos{display:flex;gap:12px;flex-wrap:wrap}
.photo{width:100px;height:100px;border-radius:18px;border:2px dashed #e5e7eb;display:flex;align-items:center;justify-content:center}
.photo img{width:100%;height:100%;object-fit:cover;border-radius:18px}
.nav{position:fixed;bottom:0;left:50%;transform:translateX(-50%);width:100%;max-width:420px;padding:14px;background:#fff;display:flex;gap:12px}
.primary{    height: 34px;flex:1;background:linear-gradient(135deg,#fd5068,#ff7854);color:#fff;border:none;border-radius:18px}
.ghost{background:none;border:none;color:#64748b}
</style>
